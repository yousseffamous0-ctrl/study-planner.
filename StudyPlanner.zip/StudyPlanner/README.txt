1) Android Studio -> Open -> choose the StudyPlanner folder, wait for Gradle sync.
2) Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).
3) On the phone: open the app -> enable the accessibility service.
   Android 13+ (APK installed outside Play): App info -> ⋮ -> "Allow restricted settings" first.
