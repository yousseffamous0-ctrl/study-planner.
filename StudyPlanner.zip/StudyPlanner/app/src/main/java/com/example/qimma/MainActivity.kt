package com.example.qimma

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout
    private lateinit var scroll: ScrollView
    private var tab = 0
    private var focusMin = 25
    private var focusTv: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private val BG = Color.parseColor("#0E1224")
    private val CARD = Color.parseColor("#1A2038")
    private val CARD2 = Color.parseColor("#2A3358")
    private val ACC = Color.parseColor("#7C6CFF")
    private val GREEN = Color.parseColor("#34D399")
    private val RED = Color.parseColor("#FF6B7A")
    private val AMBER = Color.parseColor("#FBBF24")
    private val TX = Color.WHITE
    private val MUT = Color.parseColor("#9AA3C0")

    private val ticker = object : Runnable {
        override fun run() {
            if (store.focusActive()) {
                focusTv?.text = fmtClock(store.focusRemainingSec())
                handler.postDelayed(this, 1000)
            } else {
                render()
            }
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val crash = getSharedPreferences("crash", MODE_PRIVATE).getString("t", null)
        if (crash != null) {
            getSharedPreferences("crash", MODE_PRIVATE).edit().remove("t").commit()
            val c = TextView(this)
            c.text = "حصل خطأ، ابعت صورة للشاشة دي:\n\n" + crash
            c.textSize = 11f
            c.setTextIsSelectable(true)
            c.setPadding(dp(12), dp(40), dp(12), dp(12))
            val csv = ScrollView(this)
            csv.addView(c)
            setContentView(csv)
            return
        }
        store = Store(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val rootV = LinearLayout(this)
        rootV.orientation = LinearLayout.VERTICAL
        rootV.setBackgroundColor(BG)
        rootV.layoutDirection = View.LAYOUT_DIRECTION_RTL

        scroll = ScrollView(this)
        content = vbox()
        content.setPadding(dp(16), dp(20), dp(16), dp(24))
        scroll.addView(content)
        rootV.addView(scroll, LinearLayout.LayoutParams(MP, 0, 1f))

        nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(CARD)
        nav.setPadding(0, dp(8), 0, dp(8))
        rootV.addView(nav, LinearLayout.LayoutParams(MP, WC))

        setContentView(rootV)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }

    override fun onResume() {
        super.onResume()
        if (!::store.isInitialized) return
        render()
        Scheduler.scheduleAll(this)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    // ------------------------------------------------------------ helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun text(t: String, size: Float = 15f, color: Int = TX, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD)
        return v
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    private fun put(parent: LinearLayout, v: View, top: Int = 0, bottom: Int = 0, weight: Float = 0f, w: Int = MP) {
        val lp = LinearLayout.LayoutParams(w, WC, weight)
        lp.topMargin = dp(top)
        lp.bottomMargin = dp(bottom)
        parent.addView(v, lp)
    }

    private fun card(): LinearLayout {
        val c = vbox()
        c.background = bg(CARD, 18)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        put(content, c, bottom = 12)
        return c
    }

    private fun header(t: String) {
        val v = text(t, 24f, TX, true)
        v.setPadding(0, 0, 0, dp(14))
        content.addView(v)
    }

    private fun pill(t: String, color: Int = ACC, big: Boolean = false, onClick: () -> Unit): TextView {
        val v = text(t, if (big) 16f else 13f, Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.background = bg(color, 24)
        if (big) v.setPadding(dp(20), dp(14), dp(20), dp(14)) else v.setPadding(dp(14), dp(8), dp(14), dp(8))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun headRow(parent: LinearLayout, t: String, btnText: String, onClick: () -> Unit) {
        val r = hbox()
        put(r, text(t, 16f, TX, true), weight = 1f, w = 0)
        r.addView(pill(btnText, ACC, false, onClick))
        put(parent, r, bottom = 6)
    }

    private fun bar(pct: Int, color: Int, hdp: Int = 8): LinearLayout {
        val p = pct.coerceIn(0, 100)
        val t = LinearLayout(this)
        t.orientation = LinearLayout.HORIZONTAL
        t.background = bg(CARD2, 6)
        val a = View(this)
        a.background = bg(color, 6)
        t.addView(a, LinearLayout.LayoutParams(0, dp(hdp), p.toFloat()))
        t.addView(View(this), LinearLayout.LayoutParams(0, dp(hdp), (100 - p).toFloat()))
        return t
    }

    private fun stat(icon: String, value: String, cap: String): LinearLayout {
        val c = vbox()
        c.background = bg(CARD, 16)
        c.setPadding(dp(8), dp(12), dp(8), dp(12))
        c.gravity = Gravity.CENTER_HORIZONTAL
        val i = text(icon, 20f)
        i.gravity = Gravity.CENTER
        val v = text(value, 18f, TX, true)
        v.gravity = Gravity.CENTER
        val l = text(cap, 11f, MUT)
        l.gravity = Gravity.CENTER
        c.addView(i)
        c.addView(v)
        c.addView(l)
        return c
    }

    private fun timeChip(cap: String, time: String, onClick: () -> Unit): LinearLayout {
        val c = vbox()
        c.background = bg(CARD2, 14)
        c.setPadding(dp(14), dp(10), dp(14), dp(10))
        c.addView(text(cap, 12f, MUT))
        val t = text(time, 24f, TX, true)
        t.layoutDirection = View.LAYOUT_DIRECTION_LTR
        c.addView(t)
        c.setOnClickListener { onClick() }
        return c
    }

    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun pickTime(initial: String, cb: (String) -> Unit) {
        val parts = initial.split(":")
        TimePickerDialog(
            this, android.R.style.Theme_DeviceDefault_Dialog,
            { _, hh, mm -> cb(String.format(Locale.US, "%02d:%02d", hh, mm)) },
            parts[0].toInt(), parts[1].toInt(), true
        ).show()
    }

    private fun toMin(t: String): Int {
        val p = t.split(":")
        return p[0].toInt() * 60 + p[1].toInt()
    }

    private fun fmtMin(m: Int): String =
        if (m >= 60) (m / 60).toString() + " س" + (if (m % 60 > 0) " و " + (m % 60).toString() + " د" else "")
        else m.toString() + " د"

    private fun fmtClock(sec: Int): String = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun icon(pkg: String): Drawable = try {
        packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) { packageManager.defaultActivityIcon }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/${BlockerService::class.java.name}")
    }

    private fun sleepMinutes(): Int {
        var d = toMin(store.wake) - toMin(store.sleep)
        if (d <= 0) d += 1440
        return d
    }

    private fun nextEvent(): Pair<String, Int>? {
        val now = Calendar.getInstance()
        val nm = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val ev = mutableListOf<Pair<String, Int>>()
        store.lessons().forEach { ev.add(("📚 " + it.name) to toMin(it.time)) }
        ev.add("⏰ الصحيان" to toMin(store.wake))
        ev.add("😴 النوم" to toMin(store.sleep))
        var best: Pair<String, Int>? = null
        for (e in ev) {
            var d = e.second - nm
            if (d < 0) d += 1440
            val b = best
            if (b == null || d < b.second) best = e.first to d
        }
        return best
    }

    // ------------------------------------------------------------ render

    private fun render() {
        handler.removeCallbacks(ticker)
        focusTv = null
        store.settleFocus()
        content.removeAllViews()
        when (tab) {
            0 -> home()
            1 -> plan()
            2 -> focus()
            else -> apps()
        }
        buildNav()
    }

    private fun buildNav() {
        nav.removeAllViews()
        val items = listOf("🏠" to "الرئيسية", "📅" to "الجدول", "🎯" to "التركيز", "📱" to "التطبيقات")
        items.forEachIndexed { i, item ->
            val c = vbox()
            c.gravity = Gravity.CENTER
            val e = text(item.first, 20f)
            e.gravity = Gravity.CENTER
            e.alpha = if (i == tab) 1f else 0.5f
            val l = text(item.second, 11f, if (i == tab) ACC else MUT, i == tab)
            l.gravity = Gravity.CENTER
            c.addView(e)
            c.addView(l)
            c.setOnClickListener {
                tab = i
                render()
                scroll.post { scroll.scrollTo(0, 0) }
            }
            nav.addView(c, LinearLayout.LayoutParams(0, WC, 1f))
        }
    }

    private fun a11yWarning() {
        if (a11yOn()) return
        val c = card()
        c.background = bg(Color.parseColor("#3A2E12"), 18)
        c.addView(text("⚠️ خدمة القفل مش شغّالة", 15f, AMBER, true))
        put(c, text("فعّل «قمّة» من إعدادات إمكانية الوصول عشان التطبيق يقدر يقفل التطبيقات.", 13f, TX), top = 4)
        put(c, pill("فتح الإعدادات", AMBER, false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, top = 10)
    }

    // ------------------------------------------------------------ home

    private fun home() {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = if (hr < 12) "صباح الخير ☀️" else if (hr < 18) "مساء النور 🌤️" else "مساء الخير 🌙"
        val brand = hbox()
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        val llp = LinearLayout.LayoutParams(dp(76), dp(76))
        llp.marginEnd = dp(12)
        brand.addView(logo, llp)
        val bn = vbox()
        bn.addView(text("قمّة", 30f, TX, true))
        bn.addView(text("لا تعلن الخطوات.. أعلن الوصول ⛰️", 12f, MUT))
        brand.addView(bn)
        put(content, brand, bottom = 16)

        val head = vbox()
        head.addView(text(greet, 20f, TX, true))
        head.addView(text(SimpleDateFormat("EEEE d MMMM", Locale("ar")).format(Date()), 13f, MUT))
        head.setPadding(0, 0, 0, dp(14))
        content.addView(head)

        a11yWarning()

        val light = Color.parseColor("#E3DFFF")
        val hero = card()
        hero.background = bg(ACC, 22)
        hero.addView(text("الجاي في جدولك", 13f, light))
        val ne = nextEvent()
        if (ne != null) {
            put(hero, text(ne.first, 22f, Color.WHITE, true), top = 4)
            put(hero, text("بعد " + fmtMin(ne.second), 15f, light), top = 2)
        } else {
            put(hero, text("ضيف دروس أو حدد ميعاد النوم", 16f, Color.WHITE, true), top = 4)
        }

        val pct = progressPct()
        val pc = card()
        pc.addView(text("🏔️ تقدّمك نحو القمة", 15f, TX, true))
        val allStates = store.lessons().map { it.state } + store.tasks().map { it.state }
        if (allStates.isEmpty()) {
            put(pc, text("ضيف دروس ومهام وابدأ رحلتك للقمة 🚀", 13f, MUT), top = 8)
        } else {
            put(pc, bar(pct, if (pct >= 100) GREEN else ACC, 14), top = 12)
            put(pc, text(pct.toString() + "% • " + progressMsg(pct), 13f, TX, true), top = 8)
            val dn = allStates.count { it == 2 }
            val hf = allStates.count { it == 1 }
            val fl = allStates.count { it == 3 }
            put(pc, text("✓ " + dn + "    🌗 " + hf + "    ✗ " + fl + "    من " + allStates.size, 12f, MUT), top = 4)
        }

        val tasks = store.tasks()
        val row = hbox()
        row.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val cards = listOf(
            stat("📱", fmtMin(store.history(0) / 60), "وقت التطبيقات"),
            stat("🎯", fmtMin(store.focusMinutes(0)), "تركيز النهارده"),
            stat("✅", tasks.count { it.state == 2 }.toString() + "/" + tasks.size.toString(), "المهام")
        )
        cards.forEach {
            val lp = LinearLayout.LayoutParams(0, WC, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(it, lp)
        }
        put(content, row, bottom = 12)

        // weekly chart
        val cc = card()
        cc.addView(text("📊 استخدام التطبيقات آخر ٧ أيام", 15f, TX, true))
        val vals = (6 downTo 0).map { store.history(it) }
        val mx = (vals.maxOrNull() ?: 0).coerceAtLeast(60)
        val chart = hbox()
        chart.gravity = Gravity.BOTTOM
        chart.setPadding(0, dp(16), 0, 0)
        vals.forEachIndexed { idx, v ->
            val col = vbox()
            col.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            val barV = View(this)
            barV.background = bg(if (idx == 6) ACC else CARD2, 6)
            val hpx = dp(4) + (dp(90) * v / mx)
            col.addView(barV, LinearLayout.LayoutParams(dp(18), hpx))
            val dayName = SimpleDateFormat("EEE", Locale("ar"))
                .format(Date(System.currentTimeMillis() - (6 - idx) * 86400000L))
            val lb = text(dayName, 10f, MUT)
            lb.gravity = Gravity.CENTER
            col.addView(lb)
            put(chart, col, weight = 1f, w = 0)
        }
        cc.addView(chart)

        // sleep
        val sc = card()
        sc.addView(text("😴 النوم والصحيان", 15f, TX, true))
        val r = hbox()
        val c1 = timeChip("⏰ أصحى الساعة", store.wake) {
            pickTime(store.wake) { store.wake = it; Scheduler.scheduleAll(this); render() }
        }
        val c2 = timeChip("🌙 أنام الساعة", store.sleep) {
            pickTime(store.sleep) { store.sleep = it; Scheduler.scheduleAll(this); render() }
        }
        val l1 = LinearLayout.LayoutParams(0, WC, 1f)
        l1.setMargins(0, 0, dp(6), 0)
        val l2 = LinearLayout.LayoutParams(0, WC, 1f)
        l2.setMargins(dp(6), 0, 0, 0)
        r.addView(c1, l1)
        r.addView(c2, l2)
        put(sc, r, top = 10)
        val sm = sleepMinutes()
        put(sc, text("مدة النوم: " + fmtMin(sm) + (if (sm < 420) " — حاول تنام أبكر 😴" else " ✅"), 13f, MUT), top = 10)
    }

    // ------------------------------------------------------------ plan (lessons + tasks)

    private fun pctOf(states: List<Int>): Int {
        if (states.isEmpty()) return 0
        val pts = states.fold(0) { acc, s -> acc + (if (s == 2) 2 else if (s == 1) 1 else 0) }
        return pts * 100 / (2 * states.size)
    }

    private fun progressPct(): Int =
        pctOf(store.lessons().map { it.state } + store.tasks().map { it.state })

    private fun progressMsg(p: Int): String =
        if (p >= 100) "وصلت للقمة! 🏆"
        else if (p >= 60) "قربت من القمة! 🔥"
        else if (p > 0) "بدأت صح، كمّل 💪"
        else "ابدأ بأول خطوة 🚀"

    private fun progressBlock(parent: LinearLayout, p: Int) {
        put(parent, bar(p, if (p >= 100) GREEN else ACC, 10), top = 10)
        put(parent, text(p.toString() + "% • " + progressMsg(p), 12f, MUT), top = 6)
    }

    private fun markBtn(cap: String, active: Boolean, color: Int, onClick: () -> Unit): TextView {
        val v = text(cap, 12f, if (active) Color.WHITE else MUT, true)
        v.gravity = Gravity.CENTER
        v.background = bg(if (active) color else CARD, 12)
        v.setPadding(dp(4), dp(10), dp(4), dp(10))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun statusRow(
        parent: LinearLayout, title: String, time: String?, state: Int,
        onSet: (Int) -> Unit, onDelete: () -> Unit
    ) {
        val item = vbox()
        item.background = bg(CARD2, 14)
        item.setPadding(dp(12), dp(10), dp(12), dp(10))

        val head = hbox()
        val col = vbox()
        val tt = text(title, 15f, if (state == 2) MUT else TX, true)
        if (state == 2) tt.paintFlags = tt.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        col.addView(tt)
        var sub = ""
        if (time != null) sub = "🕗 " + time
        val status = when (state) {
            1 -> "🌗 اتعمل نصها"
            2 -> "✅ خلصت"
            3 -> "❌ ماتعملتش"
            else -> ""
        }
        if (status.isNotEmpty()) sub = if (sub.isEmpty()) status else sub + "   •   " + status
        if (sub.isNotEmpty()) {
            val subColor = when (state) {
                1 -> AMBER
                2 -> GREEN
                3 -> RED
                else -> MUT
            }
            col.addView(text(sub, 12f, subColor))
        }
        put(head, col, weight = 1f, w = 0)
        val del = text("🗑️", 16f)
        del.setPadding(dp(10), dp(4), dp(4), dp(4))
        del.setOnClickListener { onDelete() }
        head.addView(del)
        item.addView(head)

        val btns = hbox()
        val bs = listOf(
            markBtn("✓ خلصت", state == 2, GREEN) { onSet(if (state == 2) 0 else 2) },
            markBtn("🌗 50%", state == 1, AMBER) { onSet(if (state == 1) 0 else 1) },
            markBtn("✗ ماعملتش", state == 3, RED) { onSet(if (state == 3) 0 else 3) }
        )
        bs.forEach {
            val lp = LinearLayout.LayoutParams(0, WC, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            btns.addView(it, lp)
        }
        put(item, btns, top = 10)
        put(parent, item, top = 10)
    }

    private fun afterMark(st: Int) {
        if (st == 2) {
            if (progressPct() == 100) {
                celebrate("🏔️ وصلت للقمة النهارده! خلّصت كل دروسك ومهامك، إنت بطل!")
            } else {
                celebrate(Quotes.done.random())
            }
        } else if (st == 1) {
            Toast.makeText(this, Quotes.half.random(), Toast.LENGTH_SHORT).show()
        } else if (st == 3) {
            Toast.makeText(this, Quotes.fail.random(), Toast.LENGTH_LONG).show()
        }
    }

    private fun celebrate(msg: String) {
        val emojis = listOf("🎉", "🏆", "🔥", "🚀", "⛰️", "⭐", "💪", "🥇")
        val box = vbox()
        box.setPadding(dp(24), dp(20), dp(24), dp(8))
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val e = text(emojis.random(), 54f)
        e.gravity = Gravity.CENTER
        val m = text(msg, 20f, TX, true)
        m.gravity = Gravity.CENTER
        box.addView(e, LinearLayout.LayoutParams(MP, WC))
        put(box, m, top = 10)
        dlg().setView(box).setPositiveButton("تمام 💪", null).show()
    }

    private fun plan() {
        header("📅 الجدول")

        val lc = card()
        headRow(lc, "📚 دروس اليوم", "＋ درس") { addLesson() }
        val ls = store.lessons()
        if (ls.isEmpty()) {
            put(lc, text("مفيش دروس لسه. ضيف أول درس.", 13f, MUT), top = 8)
        } else {
            progressBlock(lc, pctOf(ls.map { it.state }))
        }
        ls.forEach { l ->
            statusRow(lc, l.name, l.time, l.state,
                { st -> store.setLessonState(l, st); render(); afterMark(st) },
                { store.removeLesson(l); Scheduler.scheduleAll(this); render() })
        }

        val tc = card()
        headRow(tc, "📝 المهام", "＋ مهمة") { addTask() }
        val ts = store.tasks()
        if (ts.isEmpty()) {
            put(tc, text("مفيش مهام. اكتب اللي عاوز تخلصه النهارده.", 13f, MUT), top = 8)
        } else {
            progressBlock(tc, pctOf(ts.map { it.state }))
        }
        ts.forEach { t ->
            statusRow(tc, t.title, null, t.state,
                { st -> store.setTaskState(t.id, st); render(); afterMark(st) },
                { store.removeTask(t.id); render() })
        }
        if (ts.any { it.state == 2 }) {
            put(tc, pill("مسح المنتهية", CARD2, false) { store.clearDone(); render() }, top = 14)
        }
    }

    private fun addLesson() {
        val et = EditText(this)
        et.hint = "اسم الدرس (مثلاً: فيزياء)"
        et.setTextColor(TX)
        et.setHintTextColor(MUT)
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, LinearLayout.LayoutParams(MP, WC))
        dlg().setTitle("درس جديد").setView(box)
            .setPositiveButton("التالي") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) pickTime("08:00") { t ->
                    store.addLesson(n, t)
                    Scheduler.scheduleAll(this)
                    render()
                }
            }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun addTask() {
        val et = EditText(this)
        et.hint = "اكتب المهمة"
        et.setTextColor(TX)
        et.setHintTextColor(MUT)
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, LinearLayout.LayoutParams(MP, WC))
        dlg().setTitle("مهمة جديدة").setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { store.addTask(n); render() }
            }
            .setNegativeButton("إلغاء", null).show()
    }

    // ------------------------------------------------------------ focus

    private fun focus() {
        header("🎯 وضع التركيز")
        val c = card()
        if (store.focusActive()) {
            c.addView(text("جلسة تركيز شغّالة", 14f, MUT))
            val t = text(fmtClock(store.focusRemainingSec()), 56f, GREEN, true)
            t.gravity = Gravity.CENTER
            t.layoutDirection = View.LAYOUT_DIRECTION_LTR
            put(c, t, top = 8, bottom = 8)
            focusTv = t
            c.addView(text("كل التطبيقات اللي ليها حد مقفولة لحد ما الوقت يخلص 🔒", 13f, MUT))
            put(c, pill("إلغاء الجلسة", RED, true) {
                store.cancelFocus()
                Scheduler.focusAlarm(this, null)
                render()
            }, top = 16)
            handler.postDelayed(ticker, 1000)
        } else {
            c.addView(text("اختار مدة التركيز", 14f, MUT))
            val chips = hbox()
            listOf(15, 25, 45, 60).forEach { m ->
                val ch = text(m.toString() + " د", 15f, Color.WHITE, true)
                ch.gravity = Gravity.CENTER
                ch.background = bg(if (m == focusMin) ACC else CARD2, 14)
                ch.setPadding(0, dp(12), 0, dp(12))
                ch.setOnClickListener { focusMin = m; render() }
                val lp = LinearLayout.LayoutParams(0, WC, 1f)
                lp.setMargins(dp(4), 0, dp(4), 0)
                chips.addView(ch, lp)
            }
            put(c, chips, top = 12)
            put(c, pill("ابدأ التركيز 🚀", ACC, true) {
                store.startFocus(focusMin)
                Scheduler.focusAlarm(this, store.focusEndMillis())
                render()
            }, top = 16)
        }

        val s = card()
        s.addView(text("📈 تركيزك", 15f, TX, true))
        put(s, text("النهارده: " + fmtMin(store.focusMinutes(0)), 14f, MUT), top = 6)
        put(s, text("امبارح: " + fmtMin(store.focusMinutes(1)), 14f, MUT), top = 2)

        val i = card()
        i.addView(text("💡 إزاي بيشتغل؟", 15f, TX, true))
        put(i, text("وقت الجلسة، أي تطبيق ضفته في «التطبيقات» بيتقفل تلقائي لو فتحته. ذاكر بتركيز وبعدها خد استراحة.", 13f, MUT), top = 6)
    }

    // ------------------------------------------------------------ apps

    private fun apps() {
        val top = hbox()
        put(top, text("📱 حدود التطبيقات", 24f, TX, true), weight = 1f, w = 0)
        top.addView(pill("＋ تطبيق", ACC, false) { chooseApp() })
        put(content, top, bottom = 14)

        a11yWarning()

        val lim = store.limits()
        if (lim.isEmpty()) {
            val e = card()
            e.addView(text("لسه مضفتش تطبيقات", 15f, TX, true))
            put(e, text("دوس «＋ تطبيق» واختار التطبيق اللي بيضيّع وقتك (تيك توك مثلاً) وحدد له وقت في اليوم.", 13f, MUT), top = 4)
        }
        for ((pkg, min) in lim.entries.sortedBy { label(it.key) }) {
            val usedMin = store.used(pkg) / 60
            val pct = if (min > 0) usedMin * 100 / min else 100
            val color = if (pct >= 100) RED else if (pct >= 70) AMBER else GREEN

            val ac = card()
            val r = hbox()
            val iv = ImageView(this)
            iv.setImageDrawable(icon(pkg))
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            val ilp = LinearLayout.LayoutParams(dp(46), dp(46))
            ilp.marginEnd = dp(12)
            r.addView(iv, ilp)

            val col = vbox()
            col.addView(text(label(pkg), 16f, TX, true))
            col.addView(text("استخدمت " + fmtMin(usedMin) + " من " + fmtMin(min), 12f, MUT))
            put(r, col, weight = 1f, w = 0)

            val x = text("✕", 16f, RED)
            x.setPadding(dp(10), dp(6), dp(6), dp(6))
            x.setOnClickListener { store.removeLimit(pkg); render() }
            r.addView(x)
            ac.addView(r)
            put(ac, bar(pct, color), top = 12)
            ac.setOnClickListener { askLimit(pkg, min) }
        }
        if (lim.isNotEmpty()) {
            content.addView(text("دوس على أي تطبيق لتغيير الوقت.", 12f, MUT))
        }
    }

    private fun chooseApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val box = vbox()
        box.setPadding(dp(12), dp(8), dp(12), dp(8))
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val search = EditText(this)
        search.hint = "ابحث عن تطبيق"
        search.setTextColor(TX)
        search.setHintTextColor(MUT)
        val list = vbox()
        val sv = ScrollView(this)
        sv.addView(list)
        box.addView(search, LinearLayout.LayoutParams(MP, WC))
        box.addView(sv, LinearLayout.LayoutParams(MP, dp(380)))

        val d = dlg().setTitle("اختار التطبيق").setView(box).setNegativeButton("إلغاء", null).create()

        fun fill(q: String) {
            list.removeAllViews()
            all.filter { it.second.contains(q, true) }.forEach { entry ->
                val r = hbox()
                r.setPadding(dp(4), dp(8), dp(4), dp(8))
                val iv = ImageView(this)
                iv.setImageDrawable(icon(entry.first))
                val ilp = LinearLayout.LayoutParams(dp(40), dp(40))
                ilp.marginEnd = dp(12)
                r.addView(iv, ilp)
                r.addView(text(entry.second, 15f, TX))
                r.setOnClickListener {
                    d.dismiss()
                    askLimit(entry.first, store.limits()[entry.first] ?: 60)
                }
                list.addView(r)
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { fill(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        fill("")
        d.show()
    }

    private fun askLimit(pkg: String, cur: Int) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText(cur.toString())
        et.setTextColor(TX)
        et.setSelection(et.text.length)
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, LinearLayout.LayoutParams(MP, WC))
        dlg().setTitle("وقت " + label(pkg) + " في اليوم (بالدقايق)").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val m = et.text.toString().toIntOrNull() ?: 60
                store.setLimit(pkg, m.coerceIn(1, 1440))
                render()
            }
            .setNegativeButton("إلغاء", null).show()
    }
}
