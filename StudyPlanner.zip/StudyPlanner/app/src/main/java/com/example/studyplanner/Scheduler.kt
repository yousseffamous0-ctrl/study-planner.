package com.example.studyplanner

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private fun pi(ctx: Context, code: Int, title: String = "", msg: String = "", create: Boolean): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("t", title).putExtra("m", msg)
        val flags = PendingIntent.FLAG_IMMUTABLE or
            (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, code, i, flags)
    }

    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (c in listOf(1, 2) + (100..199)) pi(ctx, c, create = false)?.let { am.cancel(it); it.cancel() }
        val s = Store(ctx)
        plan(ctx, am, 1, s.wake, 0, "صباح الخير ☀️", "وقت الصحيان!")
        plan(ctx, am, 2, s.sleep, -30, "قرّب ميعاد النوم 😴", "باقي ٣٠ دقيقة. سيب الموبايل وجهّز للنوم")
        s.lessons().take(100).forEachIndexed { i, l ->
            plan(ctx, am, 100 + i, l.time, -10, "درس ${l.name} 📚", "باقي ١٠ دقايق على الدرس")
        }
    }

    private fun plan(ctx: Context, am: AlarmManager, code: Int, hhmm: String, offsetMin: Int, title: String, msg: String) {
        val (h, m) = hhmm.split(":").map { it.toInt() }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.MINUTE, offsetMin)
        }
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), pi(ctx, code, title, msg, true)!!)
        } catch (e: SecurityException) {
            // alarms not allowed on this device; app keeps working without reminders
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("rem", "تذكيرات", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(ctx, "rem")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(i.getStringExtra("t"))
            .setContentText(i.getStringExtra("m"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), n)
        Scheduler.scheduleAll(ctx) // set tomorrow's alarms
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Scheduler.scheduleAll(ctx) }
}
