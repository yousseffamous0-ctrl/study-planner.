package com.example.qimma

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private fun pi(
        ctx: Context, code: Int, title: String = "", msg: String = "",
        create: Boolean, dur: Int = 60
    ): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra("t", title).putExtra("m", msg).putExtra("d", dur)
        val flags = PendingIntent.FLAG_IMMUTABLE or
            (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, code, i, flags)
    }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    /** Re-creates every alarm: wake, sleep (+30 min before), lessons (+10 min before), timed tasks. */
    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val codes = listOf(1, 2, 4) + (100..149) + (200..249) + (300..399)
        for (c in codes) pi(ctx, c, create = false)?.let { am.cancel(it); it.cancel() }
        val s = Store(ctx)
        plan(ctx, am, 1, s.wake, 0, "☀️ صباح الخير", "وقت الصحيان! يلا نبدأ يوم جديد", 60)
        plan(ctx, am, 2, s.sleep, 0, "🌙 ميعاد النوم", "يلا نام عشان تصحى نشيط بكرة", 30)
        plan(ctx, am, 4, s.sleep, -30, "😴 قرّب ميعاد النوم", "باقي ٣٠ دقيقة، سيب الموبايل وجهّز للنوم", 12)
        s.lessons().take(50).forEachIndexed { i, l ->
            plan(ctx, am, 100 + i, l.time, 0, "📚 ميعاد درس " + l.name, "الدرس بدأ دلوقتي، يلا ذاكر!", 45)
            plan(ctx, am, 200 + i, l.time, -10, "📚 درس " + l.name + " بعد ١٠ دقايق", "جهّز كتبك وركّز", 12)
        }
        val now = System.currentTimeMillis()
        s.tasks().filter { it.at > now && (it.state == 0 || it.state == 1) }
            .take(100).forEachIndexed { i, t ->
                planAt(ctx, am, 300 + i, t.at, "📝 وقت مهمتك", t.title, 45)
            }
    }

    /** Alarm for the end of a focus session (pass null to cancel). */
    fun focusAlarm(ctx: Context, at: Long?) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        pi(ctx, 3, create = false)?.let { am.cancel(it); it.cancel() }
        if (at != null) planAt(ctx, am, 3, at, "🎉 خلصت جلسة التركيز", "عظمة! خد استراحة قصيرة", 10)
    }

    private fun plan(
        ctx: Context, am: AlarmManager, code: Int, hhmm: String, offsetMin: Int,
        title: String, msg: String, dur: Int
    ) {
        val parts = hhmm.split(":")
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
        cal.set(Calendar.MINUTE, parts[1].toInt())
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MINUTE, offsetMin)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        planAt(ctx, am, code, cal.timeInMillis, title, msg, dur)
    }

    private fun planAt(
        ctx: Context, am: AlarmManager, code: Int, at: Long,
        title: String, msg: String, dur: Int
    ) {
        try {
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(at, showIntent(ctx)),
                pi(ctx, code, title, msg, true, dur)!!
            )
        } catch (e: SecurityException) {
            // alarms not allowed on this device; the app keeps working without them
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val title = i.getStringExtra("t") ?: "تنبيه"
        val msg = i.getStringExtra("m") ?: ""
        val svc = Intent(ctx, RingService::class.java)
            .putExtra("t", title).putExtra("m", msg).putExtra("d", i.getIntExtra("d", 60))
        try {
            ctx.startForegroundService(svc)
        } catch (e: Exception) {
            fallback(ctx, title, msg)
        }
        Scheduler.scheduleAll(ctx) // set tomorrow's alarms
    }

    private fun fallback(ctx: Context, title: String, msg: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("rem", "تذكيرات", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(ctx, "rem")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(msg)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Scheduler.scheduleAll(ctx) }
}
