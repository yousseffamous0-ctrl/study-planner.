package com.example.waqti

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private fun pi(ctx: Context, code: Int, title: String = "", msg: String = "", create: Boolean): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("t", title).putExtra("m", msg)
        val flags = PendingIntent.FLAG_IMMUTABLE or
            (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, code, i, flags)
    }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (c in listOf(1, 2) + (100..199)) pi(ctx, c, create = false)?.let { am.cancel(it); it.cancel() }
        val s = Store(ctx)
        plan(ctx, am, 1, s.wake, 0, "صباح الخير ☀️", "وقت الصحيان!")
        plan(ctx, am, 2, s.sleep, -30, "قرّب ميعاد النوم 😴", "باقي ٣٠ دقيقة. سيب الموبايل وجهّز للنوم")
        s.lessons().take(100).forEachIndexed { i, l ->
            plan(ctx, am, 100 + i, l.time, -10, "درس ${l.name} 📚", "باقي ١٠ دقايق على الدرس")
        }
    }

    /** Alarm for the end of a focus session (pass null to cancel). */
    fun focusAlarm(ctx: Context, at: Long?) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        pi(ctx, 3, create = false)?.let { am.cancel(it); it.cancel() }
        if (at != null) {
            try {
                am.setAlarmClock(
                    AlarmManager.AlarmClockInfo(at, showIntent(ctx)),
                    pi(ctx, 3, "🎉 خلصت جلسة التركيز", "عظمة! خد استراحة قصيرة", true)!!
                )
            } catch (e: SecurityException) {
            }
        }
    }

    private fun plan(ctx: Context, am: AlarmManager, code: Int, hhmm: String, offsetMin: Int, title: String, msg: String) {
        val parts = hhmm.split(":")
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
        cal.set(Calendar.MINUTE, parts[1].toInt())
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MINUTE, offsetMin)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        try {
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(cal.timeInMillis, showIntent(ctx)),
                pi(ctx, code, title, msg, true)!!
            )
        } catch (e: SecurityException) {
            // alarms not allowed on this device; the app keeps working without reminders
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("rem", "تذكيرات", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(ctx, "rem")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(i.getStringExtra("t"))
            .setContentText(i.getStringExtra("m"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), n)
        Scheduler.scheduleAll(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Scheduler.scheduleAll(ctx) }
}
