package com.example.qimma

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Plays a real alarm sound (looping) + vibration until the user stops it or time runs out. */
class RingService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopSelf() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val title = intent?.getStringExtra("t") ?: "تنبيه"
        val msg = intent?.getStringExtra("m") ?: ""
        val dur = intent?.getIntExtra("d", 60) ?: 60

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel("ring", "منبهات قمّة", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        nm.createNotificationChannel(ch)

        val ui = Intent(this, AlarmActivity::class.java)
            .putExtra("t", title).putExtra("m", msg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(
            this, 11, ui, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 12, Intent(this, RingService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "ring")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(msg)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "إيقاف", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(77, n)
        }

        startSound()
        startVibration()
        try { startActivity(ui) } catch (e: Exception) {}

        handler.removeCallbacks(stopper)
        handler.postDelayed(stopper, dur * 1000L)
        return START_NOT_STICKY
    }

    private fun startSound() {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < (max * 0.6).toInt()) {
                am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.7).toInt(), 0)
            }
        } catch (e: Exception) {}
        try {
            player?.release()
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {}
    }

    private fun startVibration() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        } catch (e: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacks(stopper)
        try { player?.stop() } catch (e: Exception) {}
        try { player?.release() } catch (e: Exception) {}
        player = null
        try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).cancel() } catch (e: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}

/** Full-screen alarm screen shown over the lock screen. */
class AlarmActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#0E1224"))
        root.setPadding(dp(28), dp(28), dp(28), dp(28))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        fun label(t: String, size: Float, color: Int, bold: Boolean): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setTextColor(color)
            v.gravity = Gravity.CENTER
            if (bold) v.setTypeface(Typeface.DEFAULT_BOLD)
            return v
        }

        root.addView(label("⏰", 72f, Color.WHITE, false))
        val t = label(intent.getStringExtra("t") ?: "تنبيه", 26f, Color.WHITE, true)
        t.setPadding(0, dp(12), 0, 0)
        root.addView(t)
        val m = label(intent.getStringExtra("m") ?: "", 18f, Color.parseColor("#9AA3C0"), false)
        m.setPadding(0, dp(8), 0, 0)
        root.addView(m)
        val q = label(Quotes.done.random(), 16f, Color.parseColor("#FBBF24"), true)
        q.setPadding(0, dp(24), 0, 0)
        root.addView(q)

        val btn = label("إيقاف المنبه ⏹", 20f, Color.WHITE, true)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#7C6CFF"))
        bg.cornerRadius = dp(30).toFloat()
        btn.background = bg
        btn.setPadding(dp(40), dp(18), dp(40), dp(18))
        btn.setOnClickListener {
            startService(Intent(this, RingService::class.java).setAction("STOP"))
            finish()
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(36)
        root.addView(btn, lp)
        setContentView(root)
    }
}
