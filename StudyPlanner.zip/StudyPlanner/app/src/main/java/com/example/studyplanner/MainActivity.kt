package com.example.studyplanner

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var root: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        val sv = ScrollView(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(28))
        sv.addView(root)
        setContentView(sv)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }

    override fun onResume() {
        super.onResume()
        render()
        Scheduler.scheduleAll(this)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 16f, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(8), 0, dp(4))
        return v
    }

    private fun btn(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { f() }
        return b
    }

    private fun row(text: String, onDelete: () -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        val t = tv(text)
        t.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        r.addView(t)
        r.addView(btn("حذف") { onDelete() })
        return r
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/${BlockerService::class.java.name}")
    }

    private fun pickTime(initial: String, cb: (String) -> Unit) {
        val (hh, mm) = initial.split(":").map { it.toInt() }
        TimePickerDialog(this, { _, h, m -> cb("%02d:%02d".format(h, m)) }, hh, mm, true).show()
    }

    private fun render() {
        root.removeAllViews()
        root.addView(tv("⏰ منظّم وقت الطالب", 24f, true))

        if (!a11yOn()) {
            root.addView(tv("⚠️ فعّل خدمة «منظّم وقت الطالب» من إعدادات إمكانية الوصول عشان التطبيق يقدر يرجعك للشاشة الرئيسية لما وقت أي تطبيق يخلص."))
            root.addView(btn("فتح إعدادات إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        } else {
            root.addView(tv("✅ خدمة القفل شغالة"))
        }

        // Sleep & wake
        root.addView(tv("😴 النوم والصحيان", 20f, true))
        root.addView(btn("أصحى الساعة: ${store.wake}") {
            pickTime(store.wake) { store.wake = it; render(); Scheduler.scheduleAll(this) }
        })
        root.addView(btn("أنام الساعة: ${store.sleep}") {
            pickTime(store.sleep) { store.sleep = it; render(); Scheduler.scheduleAll(this) }
        })

        // Lessons
        root.addView(tv("📚 الدروس", 20f, true))
        val ls = store.lessons()
        if (ls.isEmpty()) root.addView(tv("مفيش دروس لسه."))
        ls.forEach { l ->
            root.addView(row("${l.name} — ${l.time}") {
                store.removeLesson(l); render(); Scheduler.scheduleAll(this)
            })
        }
        root.addView(btn("➕ إضافة درس") {
            val et = EditText(this)
            et.hint = "اسم الدرس"
            AlertDialog.Builder(this).setTitle("درس جديد").setView(et)
                .setPositiveButton("التالي") { _, _ ->
                    val n = et.text.toString().trim()
                    if (n.isNotEmpty()) pickTime("08:00") { t ->
                        store.addLesson(n, t); render(); Scheduler.scheduleAll(this)
                    }
                }
                .setNegativeButton("إلغاء", null).show()
        })

        // App limits
        root.addView(tv("📱 حدود التطبيقات", 20f, true))
        val lim = store.limits()
        if (lim.isEmpty()) root.addView(tv("لسه مضفتش تطبيقات."))
        lim.forEach { (pkg, min) ->
            val name = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            val usedMin = store.used(pkg) / 60
            root.addView(row("$name\nالنهارده: $usedMin من $min دقيقة") {
                store.removeLimit(pkg); render()
            })
        }
        root.addView(btn("➕ إضافة تطبيق") { chooseApp() })
    }

    private fun chooseApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this).setTitle("اختار التطبيق")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i -> askLimit(apps[i].first) }
            .show()
    }

    private fun askLimit(pkg: String) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText("60")
        AlertDialog.Builder(this).setTitle("أقصى وقت في اليوم (بالدقايق)").setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val m = et.text.toString().toIntOrNull() ?: 60
                store.setLimit(pkg, m.coerceAtLeast(1)); render()
            }
            .setNegativeButton("إلغاء", null).show()
    }
}
