package com.example.waqti

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Lesson(val name: String, val time: String)
data class Task(val id: Long, val title: String, val done: Boolean)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("w", Context.MODE_PRIVATE)

    private fun dayStr(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -offset)
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(c.time)
    }

    var wake: String
        get() = p.getString("wake", "07:00")!!
        set(v) { p.edit().putString("wake", v).apply() }

    var sleep: String
        get() = p.getString("sleep", "23:00")!!
        set(v) { p.edit().putString("sleep", v).apply() }

    // ---- app limits (package -> minutes) ----
    fun limits(): Map<String, Int> {
        val o = JSONObject(p.getString("limits", "{}")!!)
        return o.keys().asSequence().associateWith { o.getInt(it) }
    }
    fun setLimit(pkg: String, min: Int) {
        val o = JSONObject(p.getString("limits", "{}")!!)
        o.put(pkg, min)
        p.edit().putString("limits", o.toString()).apply()
    }
    fun removeLimit(pkg: String) {
        val o = JSONObject(p.getString("limits", "{}")!!)
        o.remove(pkg)
        p.edit().putString("limits", o.toString()).apply()
    }

    // ---- lessons ----
    fun lessons(): List<Lesson> {
        val a = JSONArray(p.getString("lessons", "[]")!!)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Lesson(o.getString("n"), o.getString("t"))
        }.sortedBy { it.time }
    }
    private fun saveLessons(l: List<Lesson>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("t", it.time)) }
        p.edit().putString("lessons", a.toString()).apply()
    }
    fun addLesson(n: String, t: String) = saveLessons(lessons() + Lesson(n, t))
    fun removeLesson(l: Lesson) {
        val cur = lessons().toMutableList()
        cur.remove(l)
        saveLessons(cur)
    }

    // ---- tasks ----
    fun tasks(): List<Task> {
        val a = JSONArray(p.getString("tasks", "[]")!!)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Task(o.getLong("i"), o.getString("t"), o.getBoolean("d"))
        }
    }
    private fun saveTasks(l: List<Task>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("i", it.id).put("t", it.title).put("d", it.done)) }
        p.edit().putString("tasks", a.toString()).apply()
    }
    fun addTask(t: String) = saveTasks(tasks() + Task(System.currentTimeMillis(), t, false))
    fun toggleTask(id: Long) = saveTasks(tasks().map { if (it.id == id) it.copy(done = !it.done) else it })
    fun removeTask(id: Long) = saveTasks(tasks().filter { it.id != id })
    fun clearDone() = saveTasks(tasks().filter { !it.done })

    // ---- daily usage of limited apps (seconds) ----
    private fun rollover() {
        val today = dayStr(0)
        if (p.getString("day", "") != today) {
            val e = p.edit()
            p.all.keys.filter { it.startsWith("u_") }.forEach { e.remove(it) }
            e.putString("day", today)
            e.apply()
        }
    }
    fun used(pkg: String): Int { rollover(); return p.getInt("u_$pkg", 0) }
    fun addUsed(pkg: String, sec: Int) {
        rollover()
        val e = p.edit()
        e.putInt("u_$pkg", used(pkg) + sec)
        val hk = "h_" + dayStr(0)
        e.putInt(hk, p.getInt(hk, 0) + sec)
        e.apply()
    }
    fun history(offset: Int): Int = p.getInt("h_" + dayStr(offset), 0)

    // ---- focus mode ----
    fun focusActive(): Boolean = System.currentTimeMillis() < p.getLong("fu", 0L)
    fun focusEndMillis(): Long = p.getLong("fu", 0L)
    fun focusRemainingSec(): Int =
        ((p.getLong("fu", 0L) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
    fun startFocus(min: Int) {
        p.edit().putLong("fu", System.currentTimeMillis() + min * 60000L)
            .putInt("fm", min).putBoolean("fc", false).apply()
    }
    fun cancelFocus() { p.edit().putLong("fu", 0L).putBoolean("fc", true).apply() }
    /** Credits a finished focus session to today's total (once). */
    fun settleFocus() {
        val fu = p.getLong("fu", 0L)
        if (fu > 0 && System.currentTimeMillis() >= fu && !p.getBoolean("fc", true)) {
            val k = "f_" + dayStr(0)
            p.edit().putInt(k, p.getInt(k, 0) + p.getInt("fm", 0)).putBoolean("fc", true).apply()
        }
    }
    fun focusMinutes(offset: Int): Int = p.getInt("f_" + dayStr(offset), 0)
}
