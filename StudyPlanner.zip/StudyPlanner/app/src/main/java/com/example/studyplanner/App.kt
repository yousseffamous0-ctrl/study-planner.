package com.example.studyplanner

import android.app.Application
import android.util.Log

/** Saves any crash text so MainActivity can show it on the next launch. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("crash", MODE_PRIVATE).edit()
                    .putString("t", Log.getStackTraceString(e)).commit()
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }
}
