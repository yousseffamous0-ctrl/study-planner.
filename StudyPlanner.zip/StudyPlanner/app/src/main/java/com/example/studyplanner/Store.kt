package com.example.studyplanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Lesson(val name: String, val time: String)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("sp", Context.MODE_PRIVATE)

    var wake: String
        get() = p.getString("wake", "07:00")!!
        set(v) { p.edit().putString("wake", v).apply() }

    var sleep: String
        get() = p.getString("sleep", "23:00")!!
        set(v) { p.edit().putString("sleep", v).apply() }

    // ---- app limits (package -> minutes) ----
    fun limits(): Map<String, Int> {
        val o = JSONObject(p.getString("limits", "{}")!!)
        return o.keys().asSequence().associateWith { o.getInt(it) }
    }
    fun setLimit(pkg: String, min: Int) {
        val o = JSONObject(p.getString("limits", "{}")!!)
        o.put(pkg, min)
        p.edit().putString("limits", o.toString()).apply()
    }
    fun removeLimit(pkg: String) {
        val o = JSONObject(p.getString("limits", "{}")!!)
        o.remove(pkg)
        p.edit().putString("limits", o.toString()).apply()
    }

    // ---- lessons ----
    fun lessons(): List<Lesson> {
        val a = JSONArray(p.getString("lessons", "[]")!!)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Lesson(o.getString("n"), o.getString("t"))
        }.sortedBy { it.time }
    }
    private fun saveLessons(l: List<Lesson>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("t", it.time)) }
        p.edit().putString("lessons", a.toString()).apply()
    }
    fun addLesson(n: String, t: String) = saveLessons(lessons() + Lesson(n, t))
    fun removeLesson(l: Lesson) {
        val cur = lessons().toMutableList()
        cur.remove(l)
        saveLessons(cur)
    }

    // ---- daily usage (seconds), resets every day ----
    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun rollover() {
        if (p.getString("day", "") != day()) {
            val e = p.edit()
            p.all.keys.filter { it.startsWith("u_") }.forEach { e.remove(it) }
            e.putString("day", day())
            e.apply()
        }
    }
    fun used(pkg: String): Int { rollover(); return p.getInt("u_$pkg", 0) }
    fun addUsed(pkg: String, sec: Int) {
        rollover()
        p.edit().putInt("u_$pkg", used(pkg) + sec).apply()
    }
}
