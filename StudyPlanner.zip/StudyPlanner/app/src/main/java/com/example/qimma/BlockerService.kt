package com.example.qimma

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Every 5 seconds it checks which app is really on screen and adds time to its
 * daily counter. When the limit is reached (or focus mode is on) it sends the
 * user Home and shows a motivational message in the middle of the screen.
 * Opening a blocked app again triggers the same thing immediately.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: Store
    private var cur: String? = null
    private var ime: Set<String> = emptySet()
    private var lastTick = 0L
    private var overlay: View? = null

    private fun ignored(pkg: String): Boolean =
        pkg == "com.android.systemui" || pkg == packageName || pkg in ime

    /** Package of the window the user is actually looking at (null if unknown). */
    private fun activePkg(): String? {
        val root = try { rootInActiveWindow } catch (e: Exception) { null }
        if (root == null) return null
        val p = root.packageName?.toString()
        try { root.recycle() } catch (e: Exception) {}
        return p
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                store.settleFocus()
                val now = System.currentTimeMillis()
                val delta = if (lastTick == 0L) 5 else ((now - lastTick) / 1000).toInt().coerceIn(1, 10)
                lastTick = now
                val on = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
                if (on) {
                    val a = activePkg()
                    if (a != null && !ignored(a)) cur = a
                    val c = cur
                    if (c != null) {
                        val lim = store.limits()[c]
                        if (lim != null) {
                            if (store.focusActive()) {
                                block(c, true)
                            } else {
                                store.addUsed(c, delta)
                                if (store.used(c) >= lim * 60) block(c, false)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // never let the loop die
            } finally {
                handler.postDelayed(this, 5000)
            }
        }
    }

    override fun onServiceConnected() {
        store = Store(this)
        ime = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.map { it.packageName }.toSet()
        handler.post(tick)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (ignored(pkg)) return
        cur = pkg
        val lim = store.limits()[pkg] ?: return
        if (store.focusActive()) block(pkg, true)
        else if (store.used(pkg) >= lim * 60) block(pkg, false)
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun block(pkg: String, focus: Boolean) {
        cur = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        showOverlay(appName(pkg), focus)
    }

    // ------------------------------------------------ centered message

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {}
    }

    private fun showOverlay(name: String, focus: Boolean) {
        if (overlay != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val d = resources.displayMetrics.density
            fun dp(v: Int) = (v * d).toInt()

            val root = FrameLayout(this)
            root.setBackgroundColor(Color.parseColor("#D90E1224"))
            root.layoutDirection = View.LAYOUT_DIRECTION_RTL

            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER_HORIZONTAL
            val cbg = GradientDrawable()
            cbg.setColor(Color.parseColor("#1A2038"))
            cbg.cornerRadius = dp(26).toFloat()
            card.background = cbg
            card.setPadding(dp(24), dp(28), dp(24), dp(22))

            fun label(t: String, size: Float, color: Int, bold: Boolean): TextView {
                val v = TextView(this)
                v.text = t
                v.textSize = size
                v.setTextColor(color)
                v.gravity = Gravity.CENTER
                if (bold) v.setTypeface(Typeface.DEFAULT_BOLD)
                return v
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            card.addView(label(if (focus) "🎯" else "🛑", 54f, Color.WHITE, false), lp)

            val title = label(
                if (focus) "وضع التركيز شغّال، $name مقفول دلوقتي" else "وقتك على $name خلص النهارده",
                16f, Color.parseColor("#FBBF24"), true
            )
            val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tlp.topMargin = dp(10)
            card.addView(title, tlp)

            val msg = label(Quotes.block.random(), 22f, Color.WHITE, true)
            val mlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            mlp.topMargin = dp(16)
            card.addView(msg, mlp)

            val btn = label("حاضر، هرجع لحلمي 💪", 16f, Color.WHITE, true)
            val bbg = GradientDrawable()
            bbg.setColor(Color.parseColor("#7C6CFF"))
            bbg.cornerRadius = dp(24).toFloat()
            btn.background = bbg
            btn.setPadding(dp(20), dp(14), dp(20), dp(14))
            btn.setOnClickListener { hideOverlay() }
            val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            blp.topMargin = dp(22)
            card.addView(btn, blp)

            val clp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
            clp.setMargins(dp(28), 0, dp(28), 0)
            root.addView(card, clp)

            val params = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(root, params)
            overlay = root
            handler.postDelayed({ hideOverlay() }, 12000)
        } catch (e: Exception) {
            overlay = null
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        hideOverlay()
        super.onDestroy()
    }
}
