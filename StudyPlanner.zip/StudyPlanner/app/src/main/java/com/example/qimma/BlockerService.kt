package com.example.qimma

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

/**
 * Watches which app is on screen. Every 5 seconds it adds time to that app's
 * daily counter. When the limit is reached (or focus mode is on), it sends the
 * user Home. Re-opening the app is blocked immediately.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: Store
    private var cur: String? = null
    private var ime: Set<String> = emptySet()

    private val tick = object : Runnable {
        override fun run() {
            store.settleFocus()
            val c = cur
            val on = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
            if (c != null && on) {
                val lim = store.limits()[c]
                if (lim != null) {
                    if (store.focusActive()) {
                        block(c, true)
                    } else {
                        store.addUsed(c, 5)
                        if (store.used(c) >= lim * 60) block(c, false)
                    }
                }
            }
            handler.postDelayed(this, 5000)
        }
    }

    override fun onServiceConnected() {
        store = Store(this)
        ime = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.map { it.packageName }.toSet()
        handler.post(tick)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg == packageName || pkg in ime) return
        cur = pkg
        val lim = store.limits()[pkg]
        if (lim != null) {
            if (store.focusActive()) block(pkg, true)
            else if (store.used(pkg) >= lim * 60) block(pkg, false)
        }
    }

    private fun block(pkg: String, focus: Boolean) {
        cur = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        val name: CharSequence = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0))
        } catch (e: Exception) { pkg }
        val msg = if (focus) "🎯 وضع التركيز شغّال، $name مقفول دلوقتي"
                  else "🛑 وقتك على $name خلص النهارده"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
